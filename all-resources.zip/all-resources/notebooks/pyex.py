def sqrt(num): 
    import math 
    return "The square root of ... : " + str(num) + " is " + str(math.sqrt(num))